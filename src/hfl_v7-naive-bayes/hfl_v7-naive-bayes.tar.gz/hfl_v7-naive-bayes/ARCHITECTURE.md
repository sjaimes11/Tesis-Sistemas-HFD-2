# HFL v7 - Gaussian Naive Bayes

## Esquema teacher -> student

- Teacher original: `Gaussian Naive Bayes`
- Student desplegable: MLP `13 -> 32 -> 16 -> 8 -> 3`
- Formato del student:
  - `ids_3class.h5`
  - `ids_3class.keras` (opcional)
- Export TinyML: `model_weights.h`

## Por que asi

Random Forest, KNN y Naive Bayes no encajan nativamente en el protocolo
de intercambio de pesos de HFL v7. Por eso aqui se usa un teacher clasico
para entrenar una red estudiante compatible con tu arquitectura actual.

## Resultado mas reciente

- Teacher accuracy: 0.6204
- Student accuracy: 0.9347
- Teacher F1 macro: 0.6840
- Student F1 macro: 0.9144

## Artefactos

- `ids_3class.h5`: student model compatible con entrenamiento posterior.
- `ids_3class.keras`: version nativa opcional.
- `model_weights.h`: pesos base para ESP32.
- `teacher_naive_bayes.joblib`: teacher clasico original.
- `training_summary.json`: metricas y configuracion del entrenamiento.
